﻿using System;
using System.Linq;
using homeworkthree.Models;
using homeworkthree.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace homeworkthree.Controllers
{
    public class PatientsController : Controller
    {

        private readonly IPatientService _patientService;
        private readonly IVaccineService _vaccineService;


        public PatientsController(IPatientService patientService, IVaccineService vaccineService)
        {
            _patientService = patientService;
            _vaccineService = vaccineService;
        }

        public IActionResult Index()
        {
            return View(_patientService.GetPatient());
        }

        [HttpGet]
        public IActionResult Add(string Name)
        {
            ViewBag.Vaccine = _vaccineService.GetVaccines()
                .Where(v => v.Total_left > 0)
                .Select(v => new SelectListItem(v.Name, v.Name))
                 .ToList();
            return View(_vaccineService.NewVaccine(Name));
        }


        [HttpPost]
        public IActionResult Add(Patient patient)
        {
            string patient_vaccine_id_match = patient.Vaccine;
            int vaccine_id = _vaccineService.GetVaccines().Where(v => v.Name == patient_vaccine_id_match).Select(v => v.Id).FirstOrDefault();
            var vaccine_ = _vaccineService.GetVaccines(vaccine_id);
            var old_left = _vaccineService.GetVaccines().Where(v => v.Id == vaccine_id).Select(v => v.Total_left).FirstOrDefault();
            vaccine_.Total_left = old_left - 1;

            string patient_vaccine = patient.Vaccine;
            int dose_count = _vaccineService.GetVaccines().Where(v => v.Name == patient_vaccine).Select(v => v.Doses).FirstOrDefault();
            var vaccine = _vaccineService.GetVaccines();
            patient.Second_dose = dose_count.ToString();


            if (patient.Second_dose == "2")
            {
                if (vaccine_.Total_left <= 0)
                {
                    patient.Second_dose = "Out of stock";
                }
                else
                {
                    patient.Second_dose = "Received";
                }
            }
            else
            {
                patient.Second_dose = "-";
            }

            _patientService.Add(patient);
            return RedirectToAction("Index");
        }

        [HttpGet]
        public IActionResult Received(int id)
        {
            return View(_patientService.GetPatients(id));
        }

        [HttpPost]
        public IActionResult Received(Vaccine vaccine,int id)
        {
            var patient = _patientService.GetPatients(id);
            int vaccine_id = _vaccineService.GetVaccines().Where(v => v.Name == patient.Vaccine).Select(v => v.Id).FirstOrDefault();
            var vaccine_ = _vaccineService.GetVaccines(vaccine_id);
            var old_left = _vaccineService.GetVaccines().Where(v => v.Id == vaccine_id).Select(v => v.Total_left).FirstOrDefault();
            vaccine_.Total_left = old_left - 1;

            DateTime today = DateTime.Today;


            patient.Second_dose = today.ToString("MM/dd/yyyy");
            

            _patientService.SaveChanges();
            return RedirectToAction("Index");
        }
    }
}
