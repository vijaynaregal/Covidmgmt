﻿using System;
using System.Linq;
using homeworkthree.Models;
using homeworkthree.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace homeworkthree.Controllers
{
    public class VaccinesController : Controller
    {

        private readonly IVaccineService _vaccineService;

        public VaccinesController(IVaccineService vaccineService)
        {
            _vaccineService = vaccineService;
        }

        public IActionResult Index()
        {
            return View(_vaccineService.GetVaccines());
        }


        [HttpGet]
        public IActionResult Add()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Add(Vaccine vaccine)
        {
            if (vaccine.Doses == 1)
            {
                vaccine.Days_between = 0;
            }
            else
            {
                vaccine.Days_between = vaccine.Days_between;
            }
            _vaccineService.AddVaccine(vaccine);
            return RedirectToAction("Index");
        }

        [HttpGet]
        public IActionResult New(string Name)
        {
            ViewBag.Name = _vaccineService.GetVaccines()
                .Where(v => v.Name != Name)
                .Select(v => new SelectListItem(v.Name, v.Id.ToString()))
                 .ToList();

            return View(_vaccineService.NewVaccine(Name));
        }

        [HttpPost]
        public IActionResult New(string Name, int Total)
        {
            int new_total = Convert.ToInt32(Total);
            int user_id = Convert.ToInt32(Name);
            var vaccine = _vaccineService.GetVaccines(user_id);
            var old_total = _vaccineService.GetVaccines().Where(v => v.Id == user_id).Select(v => v.Total).FirstOrDefault();
            var old_left = _vaccineService.GetVaccines().Where(v => v.Id == user_id).Select(v => v.Total_left).FirstOrDefault();

            vaccine.Total = old_total + new_total;
            vaccine.Total_left = old_left + new_total;

            _vaccineService.SaveChanges();
            return RedirectToAction("index");
        }

        [HttpGet]
        public IActionResult Edit(int id)
        {
            return View(_vaccineService.GetVaccines(id));
        }

        [HttpPost]
        public IActionResult Edit(int id, Vaccine update)
        {
            var vaccine = _vaccineService.GetVaccines(id);
            vaccine.Name = update.Name;
            vaccine.Doses = update.Doses;
            if (vaccine.Doses == 1)
            {
                vaccine.Days_between = 0;
            }
            else
            {
                vaccine.Days_between = update.Days_between;
            }
            _vaccineService.SaveChanges();
            return RedirectToAction("Index");
        }
    }
}
