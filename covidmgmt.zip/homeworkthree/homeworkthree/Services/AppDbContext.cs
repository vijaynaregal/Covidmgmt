﻿using System.IO;
using homeworkthree.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;

namespace homeworkthree.Services
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options): base(options) { }
        public DbSet<Vaccine> vaccines { get; set; }
        public DbSet<Patient> patient { get; set; }
    }
}