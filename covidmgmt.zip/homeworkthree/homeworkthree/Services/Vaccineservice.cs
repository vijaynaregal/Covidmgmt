﻿using System;
using System.Collections.Generic;
using System.Linq;
using homeworkthree.Models;

namespace homeworkthree.Services
{
    public interface IVaccineService
    {
        List<Vaccine> GetVaccines();
        void AddVaccine(Vaccine vaccine);
        Vaccine NewVaccine(string Name);
        Vaccine GetVaccines(int id);
        void SaveChanges();
    }

    public class VaccineService : IVaccineService
    {
        private readonly AppDbContext _db;

        public VaccineService(AppDbContext db)
        {
            _db = db;
        }

        public List<Vaccine> GetVaccines()
        {
            return _db.vaccines.ToList();
        }

        public void AddVaccine(Vaccine vaccine)
        {
            _db.vaccines.Add(vaccine);
            _db.SaveChanges();
        }

        public Vaccine NewVaccine(string Name)
        {
            return _db.vaccines.Where(v => v.Name == Name).FirstOrDefault();
        }

        public Vaccine GetVaccines(int id)
        {
            return _db.vaccines.Where(v => v.Id == id).FirstOrDefault();
        }

        public void SaveChanges() => _db.SaveChanges();
    }

    public class Vaccineservice
    {
        public Vaccineservice()
        {
        }
    }
}
