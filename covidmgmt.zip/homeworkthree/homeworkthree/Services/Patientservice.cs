﻿using System;
using System.Collections.Generic;
using System.Linq;
using homeworkthree.Models;

namespace homeworkthree.Services
{
    public interface IPatientService
    {
        List<Patient> GetPatient();
        void Add(Patient patient);
        Patient GetPatients(int id);
        void SaveChanges();
    }

    public class PatientService : IPatientService
    {
        private readonly AppDbContext _db;

        public PatientService(AppDbContext db)
        {
            _db = db;
        }

        public List<Patient> GetPatient()
        {
            return _db.patient.ToList();
        }

        public void Add(Patient patient)
        {
            _db.patient.Add(patient);
            _db.SaveChanges();
        }

        public Patient GetPatients(int id)
        {
            return _db.patient.Where(p => p.Id == id).FirstOrDefault();
        }

        public void SaveChanges() => _db.SaveChanges();
    }

    public class Patientservice
    {
        public Patientservice()
        {
        }
    }
}
