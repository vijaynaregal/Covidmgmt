﻿using System;
namespace homeworkthree.Models
{
    public class Vaccine
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int Doses { get; set; }
        public int Days_between { get; set; }
        public int Total { get; set; }
        public int Total_left { get; set; }
        public Vaccine()
        {
        }
        public Vaccine(int id, string name, int doses, int days_between, int total, int total_left)
        {
            Id = id;
            Name = name;
            Doses = doses;
            Days_between = days_between;
            Total = total;
            Total_left = total_left;
        }
    }
}

