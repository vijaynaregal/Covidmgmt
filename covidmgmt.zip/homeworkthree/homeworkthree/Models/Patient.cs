﻿using System;
namespace homeworkthree.Models
{
    public class Patient
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Vaccine { get; set; }
        public DateTime First_dose { get; set; }
        public string Second_dose { get; set; }
        public Patient()
        {
        }
        public Patient(int id, string name, string vaccine, DateTime first_dose, string second_dose)
        {
            Id = id;
            Name = name;
            Vaccine = vaccine;
            First_dose = first_dose;
            Second_dose = second_dose;
        }
    }
}

